<?php 
session_start();
require("header.php");
require("checkUser.php")?>
<h1>User Not Found <h1>
<?php require("footer.php")?>