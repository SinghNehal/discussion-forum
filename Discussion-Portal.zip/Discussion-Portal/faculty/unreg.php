<?php session_start();
 require("header.php")?>
 
 <h2>You are  not registered user!!!!<br/></h2>
<h3> <a href="register.php">Please register</a>
 </h3>
 <?php require("footer.php")?>
<h4></h4>