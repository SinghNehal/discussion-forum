<div class="cleared"></div><div class="art-Footer">
                    <div class="art-Footer-inner">
                       <!-- <a href="#" class="art-rss-tag-icon" title="RSS"></a>-->
                        <div class="art-Footer-text">
                        <p>Contact Us</p>
    <table>
    
	
    <tr><td>Name</td><td>:</td><td>dbms</td></tr>
    <tr><td rowspan="1">Contact No</td><td>:</td><td>901-----97</td></tr>
    <tr><td rowspan="1">E-Mail Add</td><td>:</td><td>dbms@gmail.com</td></tr>
   
    </table><!-- | <a href="terms.php">Terms of Use</a> 
                                | <a href="prvs.php">Privacy Statement</a> | <a href="isuser.php">Online User</a><br />
                                Copyright &copy; 2012 ---. All Rights Reserved.--></p>
                        </div>
                    </div>
                    <div class="art-Footer-background"></div>
                </div>
            </div>
        </div>
           
</body>



</html>