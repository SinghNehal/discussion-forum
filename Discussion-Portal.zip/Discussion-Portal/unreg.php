<?php 

session_start();
 require("header1.php");
 echo "<body style='background: url(res/images/im6.jpg);'>";?>
 
 <h2>Please log in/register to view the forum<br/></h2>
<h3> <a href="index.php"><u>Click here</u></a>
 </h3>
 <?php require("footer.php")?>
<h4></h4>

